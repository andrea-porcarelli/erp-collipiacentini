(function ($) {
    'use strict';

    $(document).on('click', '#miticko-test-connection', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var $result = $('#miticko-test-connection-result');
        var apiKey = $('#miticko_api_key').val();

        $btn.prop('disabled', true);
        $result.removeClass('ok ko').text(MitickoAdmin.i18n.testing);

        $.post(MitickoAdmin.ajaxUrl, {
            action: 'miticko_test_connection',
            nonce: MitickoAdmin.nonce,
            api_key: apiKey,
        }).done(function (response) {
            if (response && response.success) {
                $result.text('').addClass('ok');
                showSuccessModal();
            } else {
                var msg = (response && response.data && response.data.message) || MitickoAdmin.i18n.error;
                $result.text(msg).addClass('ko');
            }
            renderDebug(response && response.data && response.data.debug);
        }).fail(function (xhr) {
            $result.text(MitickoAdmin.i18n.error).addClass('ko');
            var debug = null;
            try { debug = (JSON.parse(xhr.responseText).data || {}).debug; } catch (e) {}
            renderDebug(debug);
        }).always(function () {
            $btn.prop('disabled', false);
        });
    });

    function renderDebug(debug) {
        var $box = $('#miticko-debug-box');
        if (!$box.length) {
            $box = $('<pre id="miticko-debug-box"></pre>').insertAfter('#miticko-test-connection-result');
        }
        if (!debug) {
            $box.hide();
            return;
        }
        $box.text(JSON.stringify(debug, null, 2)).show();
    }

    function showSuccessModal() {
        var $overlay = $('<div class="miticko-modal-overlay"></div>').css({
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,.45)', zIndex: 100000,
            display: 'flex', alignItems: 'center', justifyContent: 'center'
        });
        var $modal = $('<div class="miticko-modal"></div>').css({
            background: '#fff', borderRadius: 8, padding: '24px 28px',
            maxWidth: 420, boxShadow: '0 10px 40px rgba(0,0,0,.2)'
        });
        $('<h2></h2>').text(MitickoAdmin.i18n.success_title).css({marginTop: 0}).appendTo($modal);
        $('<button class="button button-primary"></button>')
            .text(MitickoAdmin.i18n.success_close)
            .on('click', function () { $overlay.remove(); })
            .appendTo($modal);
        $overlay.append($modal).appendTo('body');
    }

    $(document).on('click', '#miticko-manual-sync', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var $res = $('#miticko-manual-sync-result');
        $btn.prop('disabled', true);
        $res.removeClass('ok ko').text(' ' + MitickoAdmin.i18n.syncing);

        $.post(MitickoAdmin.ajaxUrl, {
            action: 'miticko_manual_sync',
            nonce: MitickoAdmin.nonce,
        }).done(function (response) {
            if (response && response.success) {
                var d = response.data || {};
                $res.addClass('ok').text(' ' + MitickoAdmin.i18n.sync_done + ' — ' + (d.count || 0) + ' prodotti in ' + (d.elapsed || 0) + 's');
                setTimeout(function () { location.reload(); }, 1500);
            } else {
                var msg = (response && response.data && response.data.message) || MitickoAdmin.i18n.sync_failed;
                $res.addClass('ko').text(' ' + msg);
            }
        }).fail(function () {
            $res.addClass('ko').text(' ' + MitickoAdmin.i18n.sync_failed);
        }).always(function () {
            $btn.prop('disabled', false);
        });
    });

    // ---- Picker prodotti Miticko (scheda prodotto WC) ----
    var pickerState = { products: [], filter: '', $modal: null };

    $(document).on('click', '#miticko-open-picker', function (e) {
        e.preventDefault();
        openPicker();
    });

    $(document).on('click', '#miticko-clear-link', function (e) {
        e.preventDefault();
        $('#miticko_id_input').val('');
        $(this).hide();
    });

    function openPicker() {
        buildPickerModal();
        pickerState.$modal.find('.miticko-picker-body').html('<p>' + MitickoAdmin.i18n.picker_loading + '</p>');
        pickerState.$modal.show();

        $.post(MitickoAdmin.ajaxUrl, {
            action:  'miticko_picker_list',
            nonce:   MitickoAdmin.nonce,
            post_id: MitickoAdmin.postId || 0
        }).done(function (resp) {
            if (resp && resp.success) {
                pickerState.products = resp.data.products || [];
                renderPickerTable();
            } else {
                var msg = (resp && resp.data && resp.data.message) || MitickoAdmin.i18n.picker_error;
                pickerState.$modal.find('.miticko-picker-body').html('<p class="ko">' + msg + '</p>');
            }
        }).fail(function () {
            pickerState.$modal.find('.miticko-picker-body').html('<p class="ko">' + MitickoAdmin.i18n.picker_error + '</p>');
        });
    }

    function buildPickerModal() {
        if (pickerState.$modal && pickerState.$modal.closest('body').length) {
            return;
        }
        var $overlay = $('<div class="miticko-picker-overlay"></div>');
        var $modal   = $('<div class="miticko-picker-modal"></div>');
        var $header  = $('<div class="miticko-picker-header"></div>');
        $('<h2></h2>').text(MitickoAdmin.i18n.picker_title).appendTo($header);
        $('<button type="button" class="button-link miticko-picker-close" aria-label="close">×</button>').appendTo($header);

        var $search  = $('<input type="search" class="miticko-picker-search" />').attr('placeholder', MitickoAdmin.i18n.picker_search);
        var $body    = $('<div class="miticko-picker-body"></div>');

        $modal.append($header).append($search).append($body);
        $overlay.append($modal).appendTo('body');

        $overlay.on('click', function (e) {
            if (e.target === this) closePicker();
        });
        $header.on('click', '.miticko-picker-close', closePicker);
        $search.on('input', function () {
            pickerState.filter = ($(this).val() || '').trim().toLowerCase();
            renderPickerTable();
        });

        pickerState.$modal = $overlay;
    }

    function closePicker() {
        if (pickerState.$modal) pickerState.$modal.hide();
    }

    function renderPickerTable() {
        var $body = pickerState.$modal.find('.miticko-picker-body');
        var items = pickerState.products;
        if (pickerState.filter) {
            items = items.filter(function (p) {
                var hay = ((p.sku || '') + ' ' + (p.name || '')).toLowerCase();
                return hay.indexOf(pickerState.filter) !== -1;
            });
        }
        if (!items.length) {
            $body.html('<p>' + MitickoAdmin.i18n.picker_empty + '</p>');
            return;
        }

        var $table = $('<table class="widefat striped miticko-picker-table"></table>');
        var $thead = $('<thead><tr></tr></thead>');
        $thead.find('tr')
            .append($('<th></th>').text(MitickoAdmin.i18n.picker_col_code))
            .append($('<th></th>').text(MitickoAdmin.i18n.picker_col_name))
            .append($('<th></th>').text(MitickoAdmin.i18n.picker_col_price))
            .append($('<th></th>').text(MitickoAdmin.i18n.picker_col_dates))
            .append($('<th></th>'));
        $table.append($thead);

        var $tbody = $('<tbody></tbody>');
        items.forEach(function (p) {
            var dates = (p.next_dates && p.next_dates.length)
                ? p.next_dates.map(formatDate).join(', ')
                : '<em>' + MitickoAdmin.i18n.picker_no_dates + '</em>';
            var $tr = $('<tr></tr>');
            $tr.append($('<td></td>').append($('<code></code>').text(p.sku || '')));
            $tr.append($('<td></td>').text(p.name || ''));
            $tr.append($('<td></td>').text(typeof p.price === 'number' ? '€ ' + p.price.toFixed(2) : ''));
            $tr.append($('<td></td>').html(dates));
            var $btn = $('<button type="button" class="button button-primary"></button>').text(MitickoAdmin.i18n.picker_select);
            $btn.on('click', function () { selectPickerProduct(p); });
            $tr.append($('<td></td>').append($btn));
            $tbody.append($tr);
        });
        $table.append($tbody);

        $body.empty().append($table);
    }

    function selectPickerProduct(p) {
        $('#miticko_id_input').val(p.id);
        $('#miticko-clear-link').show();
        closePicker();
    }

    function formatDate(iso) {
        if (!iso) return '';
        var d = new Date(iso);
        if (isNaN(d.getTime())) return iso;
        return d.toLocaleDateString(undefined, { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    $(document).on('click', '#miticko-clear-logs', function (e) {
        e.preventDefault();
        if (!window.confirm(MitickoAdmin.i18n.confirm_clear)) return;
        var $btn = $(this);
        $btn.prop('disabled', true);

        $.post(MitickoAdmin.ajaxUrl, {
            action: 'miticko_clear_logs',
            nonce: MitickoAdmin.nonce,
        }).done(function (response) {
            if (response && response.success) {
                location.reload();
            } else {
                $btn.prop('disabled', false);
            }
        }).fail(function () {
            $btn.prop('disabled', false);
        });
    });
})(jQuery);
