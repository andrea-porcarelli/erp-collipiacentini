<?php
if (! defined('ABSPATH')) {
    exit;
}

class Miticko
{
    const OPTION_API_KEY        = 'miticko_api_key';
    const OPTION_WEBHOOK_SECRET = 'miticko_webhook_secret';
    const OPTION_ENABLED        = 'miticko_enabled';
    const OPTION_AUTO_IMPORT    = 'miticko_auto_import';
    const OPTION_LAST_SYNC_AT   = 'miticko_last_sync_at';
    const PRODUCT_META_MITICKO_ID = '_miticko_id';
    const CRON_HOOK             = 'miticko_cron_sync';

    /** @deprecated Kept for migration from 0.3.0 only. */
    const OPTION_SYNC_MODE      = 'miticko_sync_mode';

    public static function boot(): void
    {
        load_plugin_textdomain('miticko', false, dirname(plugin_basename(MITICKO_PLUGIN_FILE)) . '/languages');

        if (! self::is_woocommerce_active()) {
            add_action('admin_notices', [__CLASS__, 'notice_missing_woocommerce']);
            return;
        }

        self::migrate_options();

        Miticko_Settings::register();
        Miticko_Product_Type::register();
        Miticko_Sync::register();
        Miticko_Frontend::register();
    }

    private static function migrate_options(): void
    {
        $legacy = get_option(self::OPTION_SYNC_MODE, null);
        if ($legacy === null) {
            return;
        }
        if (get_option(self::OPTION_AUTO_IMPORT, null) === null) {
            update_option(self::OPTION_AUTO_IMPORT, $legacy !== 'manual' ? 1 : 0);
        }
        delete_option(self::OPTION_SYNC_MODE);
    }

    public static function on_activate(): void
    {
        Miticko_Preconfig::apply_options();

        if (! wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 300, 'miticko_quarter_hour', self::CRON_HOOK);
        }
    }

    public static function on_deactivate(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    public static function is_enabled(): bool
    {
        return (bool) get_option(self::OPTION_ENABLED, false);
    }

    public static function auto_import_enabled(): bool
    {
        return (bool) get_option(self::OPTION_AUTO_IMPORT, true);
    }

    public static function is_woocommerce_active(): bool
    {
        return in_array('woocommerce/woocommerce.php', (array) get_option('active_plugins', []), true)
            || is_plugin_active_for_network('woocommerce/woocommerce.php');
    }

    public static function notice_missing_woocommerce(): void
    {
        echo '<div class="notice notice-error"><p><strong>Miticko:</strong> ' .
            esc_html__('WooCommerce non è attivo. Il plugin Miticko richiede WooCommerce per funzionare.', 'miticko') .
            '</p></div>';
    }
}

add_filter('cron_schedules', function ($schedules) {
    $schedules['miticko_quarter_hour'] = [
        'interval' => 15 * MINUTE_IN_SECONDS,
        'display'  => __('Ogni 15 minuti (Miticko)', 'miticko'),
    ];
    return $schedules;
});

if (! function_exists('is_plugin_active_for_network')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}
