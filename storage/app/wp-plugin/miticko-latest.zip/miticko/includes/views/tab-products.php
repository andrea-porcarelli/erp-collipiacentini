<?php
if (! defined('ABSPATH')) {
    exit;
}

$last_sync   = (string) get_option(Miticko::OPTION_LAST_SYNC_AT, '');
$count       = Miticko_Settings::count_miticko_products();
$enabled     = Miticko::is_enabled();

$products = get_posts([
    'post_type'      => 'product',
    'post_status'    => ['publish', 'draft'],
    'posts_per_page' => 20,
    'orderby'        => 'modified',
    'order'          => 'DESC',
    'tax_query'      => [[
        'taxonomy' => 'product_type',
        'field'    => 'slug',
        'terms'    => MITICKO_PRODUCT_TYPE,
    ]],
]);
?>
<h2><?php esc_html_e('Prodotti sincronizzati', 'miticko'); ?></h2>

<table class="form-table" role="presentation">
    <tbody>
        <tr>
            <th scope="row"><?php esc_html_e('Totale prodotti Miticko in WooCommerce', 'miticko'); ?></th>
            <td><strong><?php echo esc_html($count); ?></strong></td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Ultima sincronizzazione', 'miticko'); ?></th>
            <td>
                <?php echo $last_sync
                    ? esc_html(mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $last_sync))
                    : '<em>' . esc_html__('mai', 'miticko') . '</em>'; ?>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Sincronizzazione manuale', 'miticko'); ?></th>
            <td>
                <button type="button" class="button button-primary" id="miticko-manual-sync" <?php disabled(! $enabled); ?>>
                    <?php esc_html_e('Sincronizza ora', 'miticko'); ?>
                </button>
                <span id="miticko-manual-sync-result"></span>
                <?php if (! $enabled): ?>
                    <p class="description"><?php esc_html_e('Attiva prima il plugin dal tab Connessione.', 'miticko'); ?></p>
                <?php else: ?>
                    <p class="description"><?php esc_html_e('Scarica il catalogo prodotti dal master Miticko e aggiorna WooCommerce. Normalmente avviene in automatico ogni 15 minuti.', 'miticko'); ?></p>
                <?php endif; ?>
            </td>
        </tr>
    </tbody>
</table>

<h2><?php esc_html_e('Ultimi 20 prodotti aggiornati', 'miticko'); ?></h2>
<table class="widefat striped">
    <thead>
        <tr>
            <th><?php esc_html_e('Titolo', 'miticko'); ?></th>
            <th><?php esc_html_e('ID Miticko', 'miticko'); ?></th>
            <th><?php esc_html_e('SKU', 'miticko'); ?></th>
            <th><?php esc_html_e('Stato', 'miticko'); ?></th>
            <th><?php esc_html_e('Ultima modifica', 'miticko'); ?></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($products)): ?>
        <tr><td colspan="6"><em><?php esc_html_e('Nessun prodotto Miticko presente. Clicca "Sincronizza ora" o aspetta il cron.', 'miticko'); ?></em></td></tr>
    <?php else: ?>
        <?php foreach ($products as $p):
            $miticko_id = (string) get_post_meta($p->ID, Miticko::PRODUCT_META_MITICKO_ID, true);
            $sku        = (string) get_post_meta($p->ID, '_sku', true);
        ?>
        <tr>
            <td><strong><?php echo esc_html($p->post_title); ?></strong></td>
            <td><code><?php echo esc_html($miticko_id); ?></code></td>
            <td><?php echo esc_html($sku); ?></td>
            <td>
                <?php echo $p->post_status === 'publish'
                    ? '<span style="color:#1a7f37">' . esc_html__('Pubblicato', 'miticko') . '</span>'
                    : '<span style="color:#996800">' . esc_html__('Bozza', 'miticko') . '</span>'; ?>
            </td>
            <td><?php echo esc_html(mysql2date('d/m/Y H:i', $p->post_modified)); ?></td>
            <td><a href="<?php echo esc_url(get_edit_post_link($p->ID)); ?>" class="button button-small"><?php esc_html_e('Modifica', 'miticko'); ?></a></td>
        </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>
