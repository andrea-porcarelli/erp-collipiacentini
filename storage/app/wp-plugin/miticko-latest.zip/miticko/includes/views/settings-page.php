<?php
if (! defined('ABSPATH')) {
    exit;
}
/** @var string $tab */
?>
<div class="wrap miticko-settings">
    <h1><?php esc_html_e('Miticko — Impostazioni plugin', 'miticko'); ?></h1>

    <nav class="nav-tab-wrapper">
        <a href="<?php echo esc_url(Miticko_Settings::tab_url('connection')); ?>"
           class="nav-tab <?php echo $tab === 'connection' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('Connessione', 'miticko'); ?>
        </a>
        <a href="<?php echo esc_url(Miticko_Settings::tab_url('products')); ?>"
           class="nav-tab <?php echo $tab === 'products' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('Prodotti', 'miticko'); ?>
        </a>
        <a href="<?php echo esc_url(Miticko_Settings::tab_url('logs')); ?>"
           class="nav-tab <?php echo $tab === 'logs' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('Log', 'miticko'); ?>
        </a>
    </nav>

    <?php include MITICKO_PLUGIN_DIR . 'includes/views/tab-' . $tab . '.php'; ?>
</div>
