<?php
if (! defined('ABSPATH')) {
    exit;
}

$api_key        = (string) get_option(Miticko::OPTION_API_KEY, '');
$webhook_secret = (string) get_option(Miticko::OPTION_WEBHOOK_SECRET, '');
$enabled        = Miticko::is_enabled();
$auto_import    = Miticko::auto_import_enabled();
?>
<form action="options.php" method="post" id="miticko-settings-form">
    <?php settings_fields('miticko_settings'); ?>

    <h2><?php esc_html_e('Impostazioni connessione', 'miticko'); ?></h2>
    <table class="form-table" role="presentation">
        <tbody>
            <tr>
                <th scope="row">
                    <label for="<?php echo esc_attr(Miticko::OPTION_API_KEY); ?>"><?php esc_html_e('Chiave API', 'miticko'); ?></label>
                </th>
                <td>
                    <input type="text"
                           id="<?php echo esc_attr(Miticko::OPTION_API_KEY); ?>"
                           name="<?php echo esc_attr(Miticko::OPTION_API_KEY); ?>"
                           value="<?php echo esc_attr($api_key); ?>"
                           class="regular-text"
                           placeholder="<?php esc_attr_e('Incolla qui la chiave API', 'miticko'); ?>">
                    <p class="description"><?php esc_html_e('Trovi la chiave API su Miticko > impostazioni > generali', 'miticko'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="<?php echo esc_attr(Miticko::OPTION_WEBHOOK_SECRET); ?>"><?php esc_html_e('Chiave segreta webhook', 'miticko'); ?></label>
                </th>
                <td>
                    <input type="text"
                           id="<?php echo esc_attr(Miticko::OPTION_WEBHOOK_SECRET); ?>"
                           name="<?php echo esc_attr(Miticko::OPTION_WEBHOOK_SECRET); ?>"
                           value="<?php echo esc_attr($webhook_secret); ?>"
                           class="regular-text"
                           placeholder="<?php esc_attr_e('Incolla qui la chiave segreta', 'miticko'); ?>">
                    <p class="description"><?php esc_html_e('Trovi la chiave segreta su Miticko > impostazioni > generali', 'miticko'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row"></th>
                <td>
                    <button type="button" class="button button-secondary" id="miticko-test-connection">
                        <?php esc_html_e('Testa connessione', 'miticko'); ?>
                    </button>
                    <span id="miticko-test-connection-result"></span>
                </td>
            </tr>
        </tbody>
    </table>

    <h2><?php esc_html_e('Attivazione', 'miticko'); ?></h2>
    <table class="form-table" role="presentation">
        <tbody>
            <tr>
                <th scope="row"><?php esc_html_e('Attiva Miticko', 'miticko'); ?></th>
                <td>
                    <label class="miticko-switch">
                        <input type="hidden" name="<?php echo esc_attr(Miticko::OPTION_ENABLED); ?>" value="0">
                        <input type="checkbox"
                               id="<?php echo esc_attr(Miticko::OPTION_ENABLED); ?>"
                               name="<?php echo esc_attr(Miticko::OPTION_ENABLED); ?>"
                               value="1"
                               <?php checked($enabled); ?>>
                        <span class="miticko-switch-slider"></span>
                    </label>
                    <p class="description"><?php esc_html_e('Importa e tieni aggiornati i prodotti presenti su Miticko dentro a WooCommerce in modo automatico', 'miticko'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Importa automaticamente nuovi prodotti', 'miticko'); ?></th>
                <td>
                    <label class="miticko-switch">
                        <input type="hidden" name="<?php echo esc_attr(Miticko::OPTION_AUTO_IMPORT); ?>" value="0">
                        <input type="checkbox"
                               id="<?php echo esc_attr(Miticko::OPTION_AUTO_IMPORT); ?>"
                               name="<?php echo esc_attr(Miticko::OPTION_AUTO_IMPORT); ?>"
                               value="1"
                               <?php checked($auto_import); ?>>
                        <span class="miticko-switch-slider"></span>
                    </label>
                    <p class="description">
                        <?php esc_html_e('Quando attivo, ogni nuovo prodotto creato su Miticko viene importato in WooCommerce come prodotto di tipo "Miticko". Quando disattivo, i prodotti su Miticko restano disponibili solo tramite collegamento manuale da un prodotto WooCommerce esistente (campo "ID Miticko" nella scheda prodotto).', 'miticko'); ?>
                    </p>
                    <p class="description">
                        <strong><?php esc_html_e('Nota:', 'miticko'); ?></strong>
                        <?php esc_html_e('il collegamento manuale funziona sempre, indipendentemente da questa impostazione. I webhook aggiornano sempre il prezzo dei prodotti già collegati.', 'miticko'); ?>
                    </p>
                </td>
            </tr>
        </tbody>
    </table>

    <?php submit_button(__('Salva modifiche', 'miticko')); ?>
</form>
