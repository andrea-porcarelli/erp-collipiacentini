<?php
if (! defined('ABSPATH')) {
    exit;
}

$entries = Miticko_Logger::all();
?>
<h2>
    <?php esc_html_e('Log attività', 'miticko'); ?>
    <button type="button" class="button button-secondary" id="miticko-clear-logs" style="float:right">
        <?php esc_html_e('Svuota log', 'miticko'); ?>
    </button>
</h2>

<p class="description">
    <?php printf(esc_html__('Vengono conservate le ultime %d voci. Il log è scritto da: webhook in ingresso da Miticko, sync manuale, cron ogni 15 minuti, attivazione del plugin.', 'miticko'), (int) Miticko_Logger::MAX_ENTRIES); ?>
</p>

<table class="widefat striped" id="miticko-logs-table">
    <thead>
        <tr>
            <th style="width:160px"><?php esc_html_e('Data', 'miticko'); ?></th>
            <th style="width:90px"><?php esc_html_e('Livello', 'miticko'); ?></th>
            <th style="width:120px"><?php esc_html_e('Sorgente', 'miticko'); ?></th>
            <th><?php esc_html_e('Messaggio', 'miticko'); ?></th>
            <th style="width:200px"><?php esc_html_e('Contesto', 'miticko'); ?></th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($entries)): ?>
        <tr><td colspan="5"><em><?php esc_html_e('Nessun evento registrato.', 'miticko'); ?></em></td></tr>
    <?php else: ?>
        <?php foreach ($entries as $e):
            $level = $e['level'] ?? 'info';
            $color = ['info' => '#1a7f37', 'warning' => '#996800', 'error' => '#b32d2e'][$level] ?? '#2c3338';
        ?>
        <tr>
            <td><?php echo esc_html(mysql2date('d/m/Y H:i:s', $e['ts'] ?? '')); ?></td>
            <td><span style="color:<?php echo esc_attr($color); ?>;font-weight:600;text-transform:uppercase"><?php echo esc_html($level); ?></span></td>
            <td><code><?php echo esc_html($e['source'] ?? ''); ?></code></td>
            <td><?php echo esc_html($e['message'] ?? ''); ?></td>
            <td>
                <?php if (! empty($e['context']) && is_array($e['context'])): ?>
                    <code style="font-size:11px"><?php echo esc_html(wp_json_encode($e['context'])); ?></code>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>
