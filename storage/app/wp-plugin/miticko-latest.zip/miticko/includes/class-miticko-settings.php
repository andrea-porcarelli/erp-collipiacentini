<?php
if (! defined('ABSPATH')) {
    exit;
}

class Miticko_Settings
{
    const CAPABILITY = 'manage_woocommerce';
    const MENU_SLUG  = 'miticko';
    const PAGE_SLUG  = 'miticko-settings';

    const ADMIN_BASE = 'https://admin.miticko.com';

    public static function register(): void
    {
        add_action('admin_menu', [__CLASS__, 'add_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('admin_footer', [__CLASS__, 'force_external_links_new_tab']);
        add_action('wp_ajax_miticko_test_connection', [__CLASS__, 'ajax_test_connection']);
        add_action('wp_ajax_miticko_manual_sync', [__CLASS__, 'ajax_manual_sync']);
        add_action('wp_ajax_miticko_clear_logs', [__CLASS__, 'ajax_clear_logs']);
        add_action('wp_ajax_miticko_verify_product', [__CLASS__, 'ajax_verify_product']);
        add_action('wp_ajax_miticko_picker_list', [__CLASS__, 'ajax_picker_list']);
    }

    public static function current_tab(): string
    {
        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'connection';
        return in_array($tab, ['connection', 'products', 'logs'], true) ? $tab : 'connection';
    }

    public static function tab_url(string $tab): string
    {
        return admin_url('admin.php?page=' . self::MENU_SLUG . '&tab=' . $tab);
    }

    public static function add_menu(): void
    {
        add_menu_page(
            __('Miticko', 'miticko'),
            __('Miticko', 'miticko'),
            self::CAPABILITY,
            self::MENU_SLUG,
            [__CLASS__, 'render_settings'],
            'dashicons-tickets-alt',
            56
        );

        // Sostituisce l'etichetta autogenerata della voce principale.
        add_submenu_page(
            self::MENU_SLUG,
            __('Impostazioni plugin', 'miticko'),
            __('Impostazioni plugin', 'miticko'),
            self::CAPABILITY,
            self::MENU_SLUG,
            [__CLASS__, 'render_settings']
        );

        // Voci esterne: inserite direttamente in $submenu con href assoluto,
        // così il click apre admin.miticko.com invece di una pagina WP vuota.
        global $submenu;
        $external = [
            [__('Ordini ↗', 'miticko'),              '/orders'],
            [__('Prodotti ↗', 'miticko'),            '/products'],
            [__('Calendario ↗', 'miticko'),          '/calendar'],
            [__('Statistiche ↗', 'miticko'),         '/statistics'],
            [__('Impostazioni Miticko ↗', 'miticko'), '/settings'],
        ];
        foreach ($external as [$label, $path]) {
            $submenu[self::MENU_SLUG][] = [$label, self::CAPABILITY, self::ADMIN_BASE . $path];
        }
    }

    public static function force_external_links_new_tab(): void
    {
        $base = esc_js(self::ADMIN_BASE);
        echo "<script>(function(){document.querySelectorAll('#adminmenu a[href^=\"{$base}\"]').forEach(function(a){a.target='_blank';a.rel='noopener';});})();</script>";
    }

    public static function register_settings(): void
    {
        register_setting('miticko_settings', Miticko::OPTION_API_KEY, [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ]);
        register_setting('miticko_settings', Miticko::OPTION_WEBHOOK_SECRET, [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ]);
        register_setting('miticko_settings', Miticko::OPTION_ENABLED, [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => false,
        ]);
        register_setting('miticko_settings', Miticko::OPTION_AUTO_IMPORT, [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => true,
        ]);
    }

    public static function enqueue_assets(string $hook): void
    {
        $screen        = function_exists('get_current_screen') ? get_current_screen() : null;
        $is_product    = $screen && $screen->id === 'product';
        $is_miticko_ui = strpos($hook, self::MENU_SLUG) !== false;
        if (! $is_product && ! $is_miticko_ui) {
            return;
        }
        wp_enqueue_style('miticko-admin', MITICKO_PLUGIN_URL . 'assets/admin.css', [], MITICKO_PLUGIN_VERSION);
        wp_enqueue_script('miticko-admin', MITICKO_PLUGIN_URL . 'assets/admin.js', ['jquery'], MITICKO_PLUGIN_VERSION, true);
        $post_id = 0;
        if ($screen && $screen->id === 'product') {
            global $post;
            $post_id = $post ? (int) $post->ID : (int) ($_GET['post'] ?? 0);
        }

        wp_localize_script('miticko-admin', 'MitickoAdmin', [
            'ajaxUrl'    => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('miticko_admin'),
            'postId'     => $post_id,
            'i18n'       => [
                'testing'              => __('Verifica in corso…', 'miticko'),
                'success_title'        => __('Miticko — Connessione testata con successo!', 'miticko'),
                'success_close'        => __('Chiudi', 'miticko'),
                'error'                => __('Connessione fallita', 'miticko'),
                'syncing'              => __('Sincronizzazione in corso…', 'miticko'),
                'sync_done'            => __('Sincronizzazione completata', 'miticko'),
                'sync_failed'          => __('Sincronizzazione fallita', 'miticko'),
                'confirm_clear'        => __('Vuoi davvero svuotare il log?', 'miticko'),
                'logs_cleared'         => __('Log svuotato', 'miticko'),
                'picker_title'         => __('Scegli un prodotto Miticko', 'miticko'),
                'picker_loading'       => __('Caricamento prodotti…', 'miticko'),
                'picker_error'         => __('Errore nel caricamento dei prodotti Miticko', 'miticko'),
                'picker_empty'         => __('Nessun prodotto Miticko disponibile per il collegamento.', 'miticko'),
                'picker_search'        => __('Cerca per codice o nome…', 'miticko'),
                'picker_select'        => __('Seleziona', 'miticko'),
                'picker_close'         => __('Chiudi', 'miticko'),
                'picker_col_code'      => __('Codice', 'miticko'),
                'picker_col_name'      => __('Nome', 'miticko'),
                'picker_col_price'     => __('Prezzo', 'miticko'),
                'picker_col_dates'     => __('Prossime date', 'miticko'),
                'picker_no_dates'      => __('nessuna data', 'miticko'),
                'picker_excluded'      => __('%d già collegati', 'miticko'),
            ],
        ]);
    }

    public static function render_settings(): void
    {
        if (! current_user_can(self::CAPABILITY)) {
            return;
        }

        if (isset($_GET['settings-updated'])) {
            add_settings_error('miticko_messages', 'miticko_saved',
                __('Miticko: impostazioni salvate con successo', 'miticko'), 'updated');
        }
        settings_errors('miticko_messages');

        $tab = self::current_tab();
        include MITICKO_PLUGIN_DIR . 'includes/views/settings-page.php';
    }

    public static function ajax_test_connection(): void
    {
        check_ajax_referer('miticko_admin', 'nonce');

        if (! current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Non autorizzato', 'miticko')], 403);
        }

        $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
        if ($api_key === '') {
            wp_send_json_error(['message' => __('Inserisci la chiave API prima di testare', 'miticko')]);
        }

        $result = (new Miticko_Client($api_key))->health();

        $debug = [
            'url'         => Miticko_Client::api_base() . '/health',
            'ssl_verify'  => Miticko_Client::ssl_verify(),
            'status'      => $result['status'] ?? 0,
            'body'        => $result['data'] ?? null,
            'error'       => $result['error'] ?? null,
        ];

        if ($result['ok']) {
            wp_send_json_success(['data' => $result['data'], 'debug' => $debug]);
        }

        wp_send_json_error([
            'message' => $result['error'] ?? sprintf(__('HTTP %d', 'miticko'), $result['status']),
            'debug'   => $debug,
        ]);
    }

    public static function ajax_manual_sync(): void
    {
        check_ajax_referer('miticko_admin', 'nonce');
        if (! current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Non autorizzato', 'miticko')], 403);
        }

        $result = Miticko_Sync::cron_pull('manual');
        if (! empty($result['ok'])) {
            wp_send_json_success($result);
        }
        wp_send_json_error([
            'message' => __('Sincronizzazione fallita, controlla il log', 'miticko'),
            'result'  => $result,
        ]);
    }

    public static function ajax_clear_logs(): void
    {
        check_ajax_referer('miticko_admin', 'nonce');
        if (! current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Non autorizzato', 'miticko')], 403);
        }
        Miticko_Logger::clear();
        wp_send_json_success();
    }

    public static function ajax_picker_list(): void
    {
        check_ajax_referer('miticko_admin', 'nonce');
        if (! current_user_can('edit_products')) {
            wp_send_json_error(['message' => __('Non autorizzato', 'miticko')], 403);
        }

        $current_post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
        $exclude         = self::linked_miticko_ids($current_post_id);

        $result = (new Miticko_Client())->catalog_available($exclude);
        if (! $result['ok']) {
            $msg = $result['error'] ?? sprintf(__('HTTP %d', 'miticko'), $result['status'] ?? 0);
            wp_send_json_error(['message' => $msg]);
        }

        $data = $result['data'] ?? [];
        wp_send_json_success([
            'products' => $data['products'] ?? [],
            'total'    => $data['total'] ?? 0,
            'excluded' => count($exclude),
        ]);
    }

    /**
     * Elenco ID Miticko già collegati ad altri prodotti WC (per escluderli dal picker).
     * Esclude anche l'ID attualmente assegnato al post in editing (così resta visibile se
     * l'utente vuole ri-selezionarlo per sbaglio? no: non ha senso. Lo escludiamo comunque).
     */
    private static function linked_miticko_ids(int $skip_post_id = 0): array
    {
        global $wpdb;
        $meta_key = Miticko::PRODUCT_META_MITICKO_ID;
        $sql = $wpdb->prepare(
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = %s
               AND pm.meta_value <> ''
               AND p.post_type = 'product'
               AND p.post_status IN ('publish','draft','pending','private')",
            $meta_key
        );
        $rows = (array) $wpdb->get_col($sql);
        return array_values(array_filter($rows));
    }

    public static function count_miticko_products(): int
    {
        global $wpdb;
        $sql = $wpdb->prepare("
            SELECT COUNT(DISTINCT p.ID)
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
            INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = %s
            INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id AND t.slug = %s
            WHERE p.post_type = %s AND p.post_status IN ('publish','draft')
        ", 'product_type', MITICKO_PRODUCT_TYPE, 'product');

        return (int) $wpdb->get_var($sql);
    }
}
