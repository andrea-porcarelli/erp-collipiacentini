<?php
if (! defined('ABSPATH')) {
    exit;
}

class Miticko_Frontend
{
    public static function register(): void
    {
        add_action('woocommerce_' . MITICKO_PRODUCT_TYPE . '_add_to_cart', [__CLASS__, 'render_widget']);
        add_action('wp', [__CLASS__, 'maybe_override_add_to_cart']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_widget_script']);
        add_filter('woocommerce_is_purchasable', [__CLASS__, 'force_purchasable_display'], 10, 2);
    }

    public static function widget_script_url(): string
    {
        return Miticko_Client::widget_base() . '/widget.js';
    }

    public static function render_widget(): void
    {
        $product = self::current_linked_product();
        if (! $product) {
            return;
        }

        $miticko_id = (string) get_post_meta($product->get_id(), Miticko::PRODUCT_META_MITICKO_ID, true);
        if ($miticko_id === '') {
            echo '<p>' . esc_html__('Prodotto non ancora sincronizzato con Miticko.', 'miticko') . '</p>';
            return;
        }

        printf(
            '<div data-miticko-widget data-miticko-product-id="%s"></div>',
            esc_attr($miticko_id)
        );
    }

    /**
     * Per prodotti collegati che NON sono di tipo miticko (simple, variable, ecc.)
     * rimuoviamo il template nativo di add-to-cart e iniettiamo il widget al suo posto.
     */
    public static function maybe_override_add_to_cart(): void
    {
        if (is_admin() || ! function_exists('is_product') || ! is_product()) {
            return;
        }
        $product = self::current_linked_product();
        if (! $product || $product->get_type() === MITICKO_PRODUCT_TYPE) {
            // Il tipo miticko è già gestito via woocommerce_miticko_add_to_cart.
            return;
        }
        remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
        add_action('woocommerce_single_product_summary', [__CLASS__, 'render_widget'], 30);
    }

    public static function enqueue_widget_script(): void
    {
        if (! is_product()) {
            return;
        }
        if (! self::current_linked_product()) {
            return;
        }
        wp_enqueue_script('miticko-widget', self::widget_script_url(), [], MITICKO_PLUGIN_VERSION, true);
    }

    /**
     * Ritorna il WC_Product corrente SE è di tipo miticko OPPURE ha un `_miticko_id` collegato.
     * Null altrimenti. Non si fida di global $product perché alcuni temi/plugin lo sovrascrivono con una stringa.
     */
    private static function current_linked_product()
    {
        $post_id = get_the_ID();
        if (! $post_id || get_post_type($post_id) !== 'product') {
            return null;
        }
        if (! function_exists('wc_get_product')) {
            return null;
        }
        $product = wc_get_product($post_id);
        if (! is_a($product, 'WC_Product')) {
            return null;
        }
        if ($product->get_type() === MITICKO_PRODUCT_TYPE) {
            return $product;
        }
        $miticko_id = (string) get_post_meta($post_id, Miticko::PRODUCT_META_MITICKO_ID, true);
        return $miticko_id !== '' ? $product : null;
    }

    public static function force_purchasable_display(bool $purchasable, $product): bool
    {
        if ($product && $product->get_type() === MITICKO_PRODUCT_TYPE) {
            return true;
        }
        return $purchasable;
    }
}
