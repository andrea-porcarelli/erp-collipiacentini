<?php
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Log persistente del plugin salvato in una option (ring buffer).
 * Non vuole essere un sistema di logging completo: solo traccia utile
 * all'admin per capire cosa ha fatto il sync e dove sono stati gli errori.
 */
class Miticko_Logger
{
    const OPTION = 'miticko_logs';
    const MAX_ENTRIES = 100;

    public static function info(string $source, string $message, array $context = []): void
    {
        self::write('info', $source, $message, $context);
    }

    public static function warning(string $source, string $message, array $context = []): void
    {
        self::write('warning', $source, $message, $context);
    }

    public static function error(string $source, string $message, array $context = []): void
    {
        self::write('error', $source, $message, $context);
    }

    public static function all(): array
    {
        $entries = get_option(self::OPTION, []);
        return is_array($entries) ? $entries : [];
    }

    public static function clear(): void
    {
        delete_option(self::OPTION);
    }

    private static function write(string $level, string $source, string $message, array $context): void
    {
        $entries = self::all();
        array_unshift($entries, [
            'ts'      => current_time('mysql'),
            'level'   => $level,
            'source'  => $source,
            'message' => $message,
            'context' => $context,
        ]);
        if (count($entries) > self::MAX_ENTRIES) {
            $entries = array_slice($entries, 0, self::MAX_ENTRIES);
        }
        update_option(self::OPTION, $entries, false);
    }
}
