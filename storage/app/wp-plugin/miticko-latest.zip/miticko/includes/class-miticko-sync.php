<?php
if (! defined('ABSPATH')) {
    exit;
}

class Miticko_Sync
{
    public static function register(): void
    {
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
        add_action(Miticko::CRON_HOOK, [__CLASS__, 'cron_pull']);
        add_action('update_option_' . Miticko::OPTION_ENABLED, [__CLASS__, 'on_enabled_change'], 10, 2);
    }

    public static function register_routes(): void
    {
        register_rest_route('miticko/v1', '/sync', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'handle_webhook'],
            'permission_callback' => [__CLASS__, 'verify_signature'],
        ]);
    }

    public static function verify_signature(WP_REST_Request $request): bool
    {
        $secret = (string) get_option(Miticko::OPTION_WEBHOOK_SECRET, '');
        if ($secret === '') {
            Miticko_Logger::error('webhook', 'Webhook rifiutato: webhook_secret non configurato');
            return false;
        }

        $signature = $request->get_header('x-miticko-signature');
        if (! $signature) {
            Miticko_Logger::error('webhook', 'Webhook rifiutato: header X-Miticko-Signature mancante');
            return false;
        }

        $payload  = $request->get_body();
        $expected = hash_hmac('sha256', $payload, $secret);

        $ok = hash_equals($expected, $signature);
        if (! $ok) {
            Miticko_Logger::error('webhook', 'Webhook rifiutato: firma HMAC non valida');
        }
        return $ok;
    }

    public static function handle_webhook(WP_REST_Request $request)
    {
        if (! Miticko::is_enabled()) {
            Miticko_Logger::warning('webhook', 'Webhook ignorato: plugin non attivo');
            return new WP_REST_Response(['ok' => false, 'reason' => 'disabled'], 202);
        }

        $body        = $request->get_json_params();
        $event       = $body['event'] ?? '';
        $data        = $body['data']  ?? [];
        $ref         = $data['id'] ?? ($data['sku'] ?? '?');
        $auto_import = Miticko::auto_import_enabled();

        switch ($event) {
            case 'product.upserted':
                $post_id = self::find_post_by_miticko_id((string) ($data['id'] ?? ''));
                if ($post_id) {
                    $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
                    $is_miticko_type = $product && $product->get_type() === MITICKO_PRODUCT_TYPE;
                    if ($is_miticko_type) {
                        self::upsert_product($data, 'publish');
                        Miticko_Logger::info('webhook', "Upsert prodotto {$ref}", ['post_id' => $post_id]);
                    } else {
                        self::sync_price_only($post_id, $data);
                        Miticko_Logger::info('webhook', "Prezzo aggiornato per prodotto collegato {$ref}", ['post_id' => $post_id]);
                    }
                    return new WP_REST_Response(['ok' => true, 'post_id' => $post_id]);
                }
                if (! $auto_import) {
                    Miticko_Logger::info('webhook', "Prodotto {$ref} non collegato: ignorato (auto-import disattivo)");
                    return new WP_REST_Response(['ok' => true, 'skipped' => 'auto_import_off']);
                }
                $post_id = self::upsert_product($data, 'publish');
                Miticko_Logger::info('webhook', "Creato nuovo prodotto {$ref}", ['post_id' => $post_id]);
                return new WP_REST_Response(['ok' => true, 'post_id' => $post_id]);

            case 'product.hidden':
                $post_id = self::find_post_by_miticko_id((string) ($data['id'] ?? ''));
                if (! $post_id) {
                    return new WP_REST_Response(['ok' => true, 'skipped' => 'not_linked']);
                }
                $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
                if (! $product || $product->get_type() !== MITICKO_PRODUCT_TYPE) {
                    Miticko_Logger::info('webhook', "Prodotto {$ref} nascosto su Miticko: stato WP non toccato (prodotto collegato manualmente)");
                    return new WP_REST_Response(['ok' => true, 'skipped' => 'linked_not_miticko_type']);
                }
                self::upsert_product($data, 'draft');
                Miticko_Logger::info('webhook', "Prodotto {$ref} messo in bozza", ['post_id' => $post_id]);
                return new WP_REST_Response(['ok' => true, 'post_id' => $post_id]);

            case 'product.deleted':
                $post_id = self::find_post_by_miticko_id((string) ($data['id'] ?? ''));
                if (! $post_id) {
                    return new WP_REST_Response(['ok' => true, 'skipped' => 'not_linked']);
                }
                $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
                if ($product && $product->get_type() === MITICKO_PRODUCT_TYPE) {
                    wp_update_post(['ID' => $post_id, 'post_status' => 'draft']);
                    Miticko_Logger::info('webhook', "Prodotto {$ref} eliminato su Miticko, bozza su WP", ['post_id' => $post_id]);
                    return new WP_REST_Response(['ok' => true, 'post_id' => $post_id]);
                }
                delete_post_meta($post_id, Miticko::PRODUCT_META_MITICKO_ID);
                Miticko_Logger::info('webhook', "Prodotto {$ref} eliminato su Miticko: collegamento rimosso dal WC post {$post_id}");
                return new WP_REST_Response(['ok' => true, 'post_id' => $post_id, 'unlinked' => true]);

            default:
                Miticko_Logger::warning('webhook', "Evento sconosciuto: {$event}");
                return new WP_REST_Response(['ok' => false, 'reason' => 'unknown_event'], 422);
        }
    }

    private static function sync_price_only(int $post_id, array $data): void
    {
        if (! isset($data['lowest_price'])) {
            return;
        }
        $price = (string) (float) $data['lowest_price'];
        update_post_meta($post_id, '_price', $price);
        update_post_meta($post_id, '_regular_price', $price);
        if (function_exists('wc_delete_product_transients')) {
            wc_delete_product_transients($post_id);
        }
    }

    private static function upsert_product(array $data, string $status): int
    {
        $miticko_id = (string) ($data['id'] ?? '');
        if ($miticko_id === '') {
            return 0;
        }

        $post_id = self::find_post_by_miticko_id($miticko_id);
        $is_new  = ! $post_id;

        $content = $data['content'] ?? [];
        $title   = $content['long_title'] ?? $content['short_title'] ?? ($data['sku'] ?? 'Miticko');

        if ($is_new) {
            $post_id = wp_insert_post([
                'post_title'   => wp_strip_all_tags($title),
                'post_status'  => $status,
                'post_type'    => 'product',
                'post_content' => wp_kses_post($content['long_description'] ?? ''),
                'post_excerpt' => wp_kses_post($content['short_description'] ?? ''),
            ], true);

            if (is_wp_error($post_id)) {
                return 0;
            }

            wp_set_object_terms($post_id, MITICKO_PRODUCT_TYPE, 'product_type');
            update_post_meta($post_id, Miticko::PRODUCT_META_MITICKO_ID, $miticko_id);
        } else {
            wp_update_post([
                'ID'          => $post_id,
                'post_status' => $status,
            ]);
        }

        update_post_meta($post_id, '_virtual', 'yes');
        update_post_meta($post_id, '_downloadable', 'no');
        update_post_meta($post_id, '_sku', sanitize_text_field($data['sku'] ?? ''));

        if (isset($data['lowest_price'])) {
            $price = (string) (float) $data['lowest_price'];
            update_post_meta($post_id, '_price', $price);
            update_post_meta($post_id, '_regular_price', $price);
        }

        if (! empty($data['category']['label'])) {
            $term = term_exists($data['category']['label'], 'product_cat');
            if (! $term) {
                $term = wp_insert_term(sanitize_text_field($data['category']['label']), 'product_cat');
            }
            if (! is_wp_error($term)) {
                $term_id = is_array($term) ? (int) $term['term_id'] : (int) $term;
                wp_set_object_terms($post_id, [$term_id], 'product_cat');
            }
        }

        if ($is_new && ! empty($data['images'])) {
            self::attach_first_image($post_id, $data['images'][0]['url']);
        }

        return (int) $post_id;
    }

    private static function find_post_by_miticko_id(string $miticko_id): int
    {
        if ($miticko_id === '') {
            return 0;
        }
        $posts = get_posts([
            'post_type'      => 'product',
            'post_status'    => 'any',
            'meta_key'       => Miticko::PRODUCT_META_MITICKO_ID,
            'meta_value'     => $miticko_id,
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]);
        return (int) ($posts[0] ?? 0);
    }


    private static function attach_first_image(int $post_id, string $url): void
    {
        if ($url === '' || get_post_thumbnail_id($post_id)) {
            return;
        }
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url($url, 30);
        if (is_wp_error($tmp)) {
            return;
        }
        $attach_id = media_handle_sideload([
            'name'     => basename(parse_url($url, PHP_URL_PATH)) ?: 'miticko.jpg',
            'tmp_name' => $tmp,
        ], $post_id);

        if (! is_wp_error($attach_id)) {
            set_post_thumbnail($post_id, $attach_id);
        } else {
            @unlink($tmp);
        }
    }

    public static function cron_pull(string $trigger = 'cron'): array
    {
        if (! Miticko::is_enabled()) {
            Miticko_Logger::warning($trigger, 'Sync non eseguito: plugin non attivo');
            return ['ok' => false, 'reason' => 'disabled', 'count' => 0];
        }

        $start       = microtime(true);
        $client      = new Miticko_Client();
        $auto_import = Miticko::auto_import_enabled();
        $page        = 1;
        $count       = 0;
        $skipped     = 0;
        $failures    = 0;

        do {
            $result = $client->catalog($page, 100);
            if (! $result['ok']) {
                $failures++;
                Miticko_Logger::error($trigger, "Errore GET /catalog pagina {$page}", [
                    'status' => $result['status'] ?? 0,
                    'error'  => $result['error'] ?? null,
                ]);
                break;
            }
            $products = $result['data']['products'] ?? [];
            foreach ($products as $product) {
                $outcome = self::apply_catalog_item($product, $auto_import);
                if ($outcome === 'applied') {
                    $count++;
                } else {
                    $skipped++;
                }
            }
            $pagination = $result['data']['pagination'] ?? ['total_pages' => 1];
            $page++;
        } while ($page <= ($pagination['total_pages'] ?? 1));

        update_option(Miticko::OPTION_LAST_SYNC_AT, current_time('mysql'));

        $elapsed = round(microtime(true) - $start, 2);
        $summary = "{$count} aggiornati, {$skipped} ignorati in {$elapsed}s";
        if ($failures > 0) {
            Miticko_Logger::warning($trigger, "Sync completato con errori: {$summary}");
        } else {
            Miticko_Logger::info($trigger, "Sync completato: {$summary}");
        }

        return ['ok' => $failures === 0, 'count' => $count, 'skipped' => $skipped, 'elapsed' => $elapsed];
    }

    /**
     * Applica un item del catalogo rispettando le regole di convivenza:
     * - prodotto già collegato di tipo miticko → upsert completo
     * - prodotto già collegato NON di tipo miticko → solo prezzo
     * - prodotto non collegato → se auto_import ON crea un miticko-type, altrimenti salta.
     *
     * Ritorna 'applied' se qualcosa è stato scritto, 'skipped' altrimenti.
     */
    private static function apply_catalog_item(array $data, bool $auto_import): string
    {
        $post_id = self::find_post_by_miticko_id((string) ($data['id'] ?? ''));
        if ($post_id) {
            $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
            if ($product && $product->get_type() === MITICKO_PRODUCT_TYPE) {
                self::upsert_product($data, 'publish');
            } else {
                self::sync_price_only($post_id, $data);
            }
            return 'applied';
        }
        if (! $auto_import) {
            return 'skipped';
        }
        self::upsert_product($data, 'publish');
        return 'applied';
    }

    public static function on_enabled_change($old_value, $new_value): void
    {
        if ((bool) $new_value && ! (bool) $old_value) {
            if (! Miticko::auto_import_enabled()) {
                Miticko_Logger::info('activation', 'Plugin attivato con auto-import disattivo: sync completa non richiesta');
                return;
            }
            Miticko_Logger::info('activation', 'Plugin attivato, richiesta sync completa al master Miticko');
            $result = (new Miticko_Client())->trigger_full_sync();
            if (! $result['ok']) {
                Miticko_Logger::error('activation', 'Richiesta sync completa fallita', [
                    'status' => $result['status'] ?? 0,
                    'error'  => $result['error'] ?? null,
                ]);
            }
        }
    }
}
