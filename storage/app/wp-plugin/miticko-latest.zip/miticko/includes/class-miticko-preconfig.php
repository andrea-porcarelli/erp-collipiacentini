<?php
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Preconfigurazione iniettata dallo zip generato dall'ERP Miticko.
 *
 * Lo zip del plugin servito da `GET /partners/{id}/plugin` del backoffice include
 * un file `includes/miticko-partner-config.php` che definisce costanti
 * `MITICKO_PREINSTALLED_*`. Questa classe le trasferisce in `wp_options` alla
 * prima attivazione, in modo che il partner non debba configurare nulla a mano.
 *
 * Idempotente: un'opzione gia' valorizzata non viene mai sovrascritta
 * (first-wins, protegge le scelte manuali del partner).
 */
class Miticko_Preconfig
{
    public static function apply_options(): void
    {
        self::seed_option_if_empty('MITICKO_PREINSTALLED_API_KEY', Miticko::OPTION_API_KEY);
        self::seed_option_if_empty('MITICKO_PREINSTALLED_WEBHOOK_SECRET', Miticko::OPTION_WEBHOOK_SECRET);

        if (defined('MITICKO_PREINSTALLED_AUTO_ENABLE') && MITICKO_PREINSTALLED_AUTO_ENABLE) {
            if (get_option(Miticko::OPTION_ENABLED, null) === null) {
                update_option(Miticko::OPTION_ENABLED, 1);
            }
        }
    }

    private static function seed_option_if_empty(string $constant, string $option): void
    {
        if (! defined($constant)) {
            return;
        }
        $value = (string) constant($constant);
        if ($value === '') {
            return;
        }
        $current = (string) get_option($option, '');
        if ($current !== '') {
            return;
        }
        update_option($option, $value);
    }
}
