<?php
if (! defined('ABSPATH')) {
    exit;
}

class Miticko_Product_Type
{
    public static function register(): void
    {
        add_action('init', [__CLASS__, 'register_type']);
        add_action('init', [__CLASS__, 'disable_native_sku_field'], 20);
        add_filter('product_type_selector', [__CLASS__, 'add_type_option']);
        add_filter('woocommerce_product_class', [__CLASS__, 'map_product_class'], 10, 2);
        add_filter('woocommerce_product_data_tabs', [__CLASS__, 'filter_tabs'], 20);
        add_action('woocommerce_product_options_general_product_data', [__CLASS__, 'render_sku_field']);
        add_action('woocommerce_product_options_general_product_data', [__CLASS__, 'render_link_field']);
        add_action('woocommerce_process_product_meta', [__CLASS__, 'save_link_field'], 10, 1);
        add_action('admin_notices', [__CLASS__, 'show_product_banner']);
        add_action('admin_footer', [__CLASS__, 'lock_product_fields']);
        add_filter('product_type_options', [__CLASS__, 'disable_type_options'], 10);
    }

    /**
     * Rimuove il render nativo del campo SKU (tab Inventario) perché noi lo
     * mostriamo nella tab Generale per ogni tipo di prodotto.
     */
    public static function disable_native_sku_field(): void
    {
        remove_action('woocommerce_product_options_sku', 'wc_product_options_sku');
    }

    public static function normalize_miticko_id(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '';
        }
        if (stripos($raw, 'ERP-PROD-') === 0) {
            return 'ERP-PROD-' . (int) substr($raw, 9);
        }
        if (ctype_digit($raw)) {
            return 'ERP-PROD-' . (int) $raw;
        }
        return $raw;
    }

    public static function register_type(): void
    {
        require_once MITICKO_PLUGIN_DIR . 'includes/class-wc-product-miticko.php';
    }

    public static function add_type_option(array $types): array
    {
        // Il tipo "Miticko" NON deve essere selezionabile a mano: lo si assegna solo
        // in fase di import automatico. Lo esponiamo nel selector unicamente quando
        // il prodotto corrente è GIÀ di quel tipo, così l'etichetta si vede in edit.
        global $post;
        $product = $post ? wc_get_product($post->ID) : null;
        if ($product && $product->get_type() === MITICKO_PRODUCT_TYPE) {
            $types[MITICKO_PRODUCT_TYPE] = __('Miticko', 'miticko');
        }
        return $types;
    }

    public static function map_product_class(string $classname, string $product_type): string
    {
        return $product_type === MITICKO_PRODUCT_TYPE ? 'WC_Product_Miticko' : $classname;
    }

    public static function filter_tabs(array $tabs): array
    {
        global $post;
        if (! $post || 'product' !== $post->post_type) {
            return $tabs;
        }
        $product = wc_get_product($post->ID);
        if (! $product || $product->get_type() !== MITICKO_PRODUCT_TYPE) {
            return $tabs;
        }

        $allowed = ['general', 'linked_product', 'advanced'];
        foreach (array_keys($tabs) as $slug) {
            if (! in_array($slug, $allowed, true)) {
                unset($tabs[$slug]);
            }
        }

        return $tabs;
    }

    public static function render_sku_field(): void
    {
        global $post;
        if (! $post || $post->post_type !== 'product') {
            return;
        }
        $product = wc_get_product($post->ID);
        if (! $product) {
            return;
        }
        if (function_exists('wc_product_sku_enabled') && ! wc_product_sku_enabled()) {
            return;
        }

        $is_miticko = $product->get_type() === MITICKO_PRODUCT_TYPE;
        $args = [
            'id'       => '_sku',
            'value'    => $product->get_sku('edit'),
            'label'    => __('Codice articolo', 'miticko'),
            'desc_tip' => true,
        ];
        if ($is_miticko) {
            $args['description']       = __('Codice articolo sincronizzato da Miticko.', 'miticko');
            $args['custom_attributes'] = ['readonly' => 'readonly'];
        } else {
            $args['description'] = __('Codice articolo (SKU) del prodotto.', 'miticko');
        }

        echo '<div class="options_group miticko-sku-group">';
        woocommerce_wp_text_input($args);
        echo '</div>';
    }

    public static function render_link_field(): void
    {
        global $post;
        if (! $post || $post->post_type !== 'product') {
            return;
        }
        $product = wc_get_product($post->ID);
        if (! $product || $product->get_type() === MITICKO_PRODUCT_TYPE) {
            return;
        }

        $current = (string) get_post_meta($post->ID, Miticko::PRODUCT_META_MITICKO_ID, true);

        echo '<div class="options_group miticko-link-group">';
        echo '<p class="form-field miticko_id_field">';
        echo '<label for="miticko_id_input">' . esc_html__('ID Miticko', 'miticko') . '</label>';
        printf(
            '<input type="text" class="short" style="width:14em" id="miticko_id_input" name="miticko_id_input" value="%s" placeholder="%s" autocomplete="off" readonly>',
            esc_attr($current),
            esc_attr__('nessun prodotto collegato', 'miticko')
        );
        echo ' <button type="button" class="button button-primary" id="miticko-open-picker">' . esc_html__('Scegli da Miticko', 'miticko') . '</button>';
        echo ' <button type="button" class="button" id="miticko-clear-link"' . ($current === '' ? ' style="display:none"' : '') . '>' . esc_html__('Scollega', 'miticko') . '</button>';
        echo '<span class="description" style="display:block;margin-top:6px">' . esc_html__('Collega questo prodotto a un prodotto Miticko scegliendolo dalla lista. Il prezzo verrà poi aggiornato automaticamente dai webhook Miticko.', 'miticko') . '</span>';
        echo '</p>';
        echo '</div>';
    }

    public static function save_link_field(int $post_id): void
    {
        if (! isset($_POST['miticko_id_input'])) {
            return;
        }
        if (! current_user_can('edit_product', $post_id)) {
            return;
        }
        $product = wc_get_product($post_id);
        if ($product && $product->get_type() === MITICKO_PRODUCT_TYPE) {
            return;
        }

        $normalized = self::normalize_miticko_id(sanitize_text_field(wp_unslash($_POST['miticko_id_input'])));
        if ($normalized === '') {
            delete_post_meta($post_id, Miticko::PRODUCT_META_MITICKO_ID);
            return;
        }
        update_post_meta($post_id, Miticko::PRODUCT_META_MITICKO_ID, $normalized);
    }


    public static function disable_type_options(array $options): array
    {
        $screen = get_current_screen();
        if ($screen && $screen->id === 'product') {
            global $post;
            $product = $post ? wc_get_product($post->ID) : null;
            if ($product && $product->get_type() === MITICKO_PRODUCT_TYPE) {
                foreach ($options as $key => $opt) {
                    $options[$key]['wrapper_class'] = ($opt['wrapper_class'] ?? '') . ' miticko-locked';
                }
            }
        }
        return $options;
    }

    public static function show_product_banner(): void
    {
        $screen = get_current_screen();
        if (! $screen || $screen->id !== 'product') {
            return;
        }
        global $post;
        $product = $post ? wc_get_product($post->ID) : null;
        if (! $product) {
            return;
        }

        $is_miticko = $product->get_type() === MITICKO_PRODUCT_TYPE;
        $miticko_id = (string) get_post_meta($post->ID, Miticko::PRODUCT_META_MITICKO_ID, true);
        $is_linked  = ! $is_miticko && $miticko_id !== '';

        if (! $is_miticko && ! $is_linked) {
            return;
        }

        $numeric_id = stripos($miticko_id, 'ERP-PROD-') === 0 ? substr($miticko_id, 9) : $miticko_id;
        $admin_url  = 'https://admin.miticko.com/products/' . rawurlencode($numeric_id);

        echo '<div class="notice notice-info"><p>';
        if ($is_miticko) {
            echo '<strong>' . esc_html__('Prodotto creato su Miticko', 'miticko') . '</strong> — ';
            echo esc_html__('puoi modificare la disponibilità del prodotto direttamente dal pannello di amministrazione di Miticko.', 'miticko');
        } else {
            echo '<strong>' . esc_html__('Prodotto collegato a Miticko', 'miticko') . '</strong> — ';
            printf(
                esc_html__('Il widget di prenotazione Miticko sostituirà il pulsante "aggiungi al carrello". ID collegato: %s.', 'miticko'),
                '<code>' . esc_html($miticko_id) . '</code>'
            );
        }
        echo ' <a href="' . esc_url($admin_url) . '" target="_blank" rel="noopener">' .
            esc_html__('Apri su Miticko', 'miticko') . ' ↗</a>';
        echo '</p></div>';
    }

    public static function lock_product_fields(): void
    {
        $screen = get_current_screen();
        if (! $screen || $screen->id !== 'product') {
            return;
        }
        global $post;
        $product = $post ? wc_get_product($post->ID) : null;
        if (! $product || $product->get_type() !== MITICKO_PRODUCT_TYPE) {
            return;
        }
        ?>
        <style>
            #product-type { pointer-events: none; opacity: .6; }
            label[for="_virtual"], label[for="_downloadable"] { opacity: .6; pointer-events: none; }
        </style>
        <script>
            (function () {
                var virt = document.getElementById('_virtual');
                var down = document.getElementById('_downloadable');
                if (virt) { virt.checked = true; virt.disabled = true; }
                if (down) { down.checked = false; down.disabled = true; }
                var typeSel = document.getElementById('product-type');
                if (typeSel) { typeSel.disabled = true; }

                var sku = document.querySelector('#general_product_data ._sku_field');
                if (sku) {
                    document.querySelectorAll('#general_product_data .options_group').forEach(function (g) {
                        if (!g.contains(sku)) { g.style.display = 'none'; }
                    });
                    var group = sku.closest('.options_group');
                    if (group) {
                        Array.prototype.forEach.call(group.children, function (child) {
                            if (child !== sku) { child.style.display = 'none'; }
                        });
                    }
                }
            })();
        </script>
        <?php
    }
}
