<?php
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Client HTTP verso le API V1 di Miticko (admin.miticko.com/api/v1).
 */
class Miticko_Client
{
    const API_BASE_DEFAULT = 'https://admin.miticko.com/api/v1';

    private string $api_key;

    public static function api_base(): string
    {
        if (defined('MITICKO_API_BASE') && MITICKO_API_BASE) {
            return rtrim((string) MITICKO_API_BASE, '/');
        }

        return self::API_BASE_DEFAULT;
    }

    public static function ssl_verify(): bool
    {
        if (! defined('MITICKO_API_SSL_VERIFY')) {
            return true;
        }

        return (bool) filter_var(MITICKO_API_SSL_VERIFY, FILTER_VALIDATE_BOOLEAN);
    }

    public static function widget_base(): string
    {
        if (defined('MITICKO_WIDGET_BASE') && MITICKO_WIDGET_BASE) {
            return rtrim((string) MITICKO_WIDGET_BASE, '/');
        }

        // Fallback: deriva dall'API base rimuovendo /api/v1.
        $apiBase = self::api_base();
        if (preg_match('#^(https?://[^/]+)#i', $apiBase, $m)) {
            return $m[1];
        }

        return 'https://widget.miticko.com';
    }

    public function __construct(?string $api_key = null)
    {
        $this->api_key = $api_key ?? (string) get_option(Miticko::OPTION_API_KEY, '');
    }

    public function health(): array
    {
        return $this->request('GET', '/health');
    }

    public function catalog(int $page = 1, int $per_page = 100): array
    {
        return $this->request('GET', '/catalog', [
            'query' => ['page' => $page, 'per_page' => $per_page],
        ]);
    }

    public function product(string $id): array
    {
        return $this->request('GET', '/products/' . rawurlencode($id));
    }

    public function catalog_available(array $exclude = []): array
    {
        return $this->request('GET', '/catalog/available', [
            'query' => ['exclude' => array_values($exclude)],
        ]);
    }

    public function catalog_info(): array
    {
        return $this->request('GET', '/catalog/info');
    }

    public function trigger_full_sync(): array
    {
        return $this->request('POST', '/sync/trigger');
    }

    private function request(string $method, string $path, array $options = []): array
    {
        if ($this->api_key === '') {
            return ['ok' => false, 'status' => 0, 'error' => __('Chiave API non configurata', 'miticko')];
        }

        $url = self::api_base() . $path;
        if (! empty($options['query'])) {
            $url .= '?' . http_build_query($options['query']);
        }

        $args = [
            'method'    => $method,
            'timeout'   => 20,
            'sslverify' => self::ssl_verify(),
            'headers'   => [
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key,
            ],
        ];

        if (! empty($options['body'])) {
            $args['body'] = wp_json_encode($options['body']);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return ['ok' => false, 'status' => 0, 'error' => $response->get_error_message()];
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $body   = json_decode(wp_remote_retrieve_body($response), true);

        return [
            'ok'     => $status >= 200 && $status < 300,
            'status' => $status,
            'data'   => $body,
        ];
    }
}
