<?php
if (! defined('ABSPATH')) {
    exit;
}

if (! class_exists('WC_Product_Simple') || class_exists('WC_Product_Miticko')) {
    return;
}

class WC_Product_Miticko extends WC_Product_Simple
{
    public function get_type()
    {
        return MITICKO_PRODUCT_TYPE;
    }

    public function is_virtual()
    {
        return true;
    }

    public function is_downloadable()
    {
        return false;
    }

    public function is_purchasable()
    {
        return false;
    }

    public function add_to_cart_url()
    {
        return get_permalink($this->get_id());
    }

    public function add_to_cart_text()
    {
        return __('Prenota', 'miticko');
    }
}
