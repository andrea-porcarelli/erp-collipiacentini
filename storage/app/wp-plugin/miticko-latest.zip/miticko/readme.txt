=== Miticko ===
Contributors: collitaliani
Tags: woocommerce, booking, miticko
Requires at least: 6.4
Tested up to: 6.6
Requires PHP: 8.1
Stable tag: 0.2.0
License: Proprietary

Collega WooCommerce a Miticko: importa i prodotti, li tiene aggiornati e sostituisce il pulsante "aggiungi al carrello" con il widget di prenotazione Miticko.

== Descrizione ==

Il plugin Miticko importa i prodotti del partner da Miticko a WooCommerce e li tiene aggiornati in automatico. Sulla pagina prodotto il visitatore prenota e paga con il widget Miticko (data, orario, visitatori, pagamento).

**Divisione dei compiti:**
* WooCommerce gestisce la pagina pubblica: titolo, descrizione, immagini, categorie, tag, SEO, URL, layout.
* Miticko gestisce disponibilità, varianti, prezzi, posti, pagamento, ordini, biglietti QR, commissioni.

== Installazione ==

1. Carica il plugin da Bacheca → Plugin → Aggiungi nuovo → Carica plugin.
2. Attiva il plugin.
3. Nel menu laterale di WordPress compare la voce "Miticko".
4. Vai su Miticko → Impostazioni plugin.
5. Inserisci la Chiave API e la Chiave segreta webhook (le trovi su admin.miticko.com → impostazioni → generali).
6. Clicca "Testa connessione" per verificare.
7. Attiva l'interruttore "Attiva Miticko" e salva.

== Changelog ==

= 0.2.0 =
* Widget frontend ora si inietta nel DOM via Shadow DOM (nessun iframe), caricamento async.
* Nuovo endpoint /api/v1/public/widget/token per rilascio token short-lived.
* CORS aperto su /api/v1/public/* e /api/v1/widget/*.

= 0.1.0 =
* Versione iniziale: scaffolding del plugin, pagina impostazioni, product type miticko, receiver webhook, widget frontend.
