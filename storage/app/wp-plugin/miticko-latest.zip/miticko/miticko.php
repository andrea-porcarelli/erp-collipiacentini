<?php
/**
 * Plugin Name: Miticko
 * Plugin URI:  https://miticko.com
 * Description: Collega WooCommerce a Miticko: importa i prodotti, li tiene aggiornati e sostituisce il pulsante "aggiungi al carrello" con il widget di prenotazione Miticko.
 * Version:     0.7.0
 * Author:      Colli Italiani SNC
 * Author URI:  https://miticko.com
 * Text Domain: miticko
 * Domain Path: /languages
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * WC requires at least: 8.0
 * WC tested up to: 9.0
 */

if (! defined('ABSPATH')) {
    exit;
}

define('MITICKO_PLUGIN_FILE', __FILE__);
define('MITICKO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MITICKO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MITICKO_PLUGIN_VERSION', '0.7.0');
define('MITICKO_PRODUCT_TYPE', 'miticko');

// File di preconfig iniettato dall'ERP nello zip partner-specifico (vedi
// PartnerController::downloadPlugin). Caricato PRIMA degli altri include
// perche' puo' definire MITICKO_API_BASE con pattern defined()/first-wins.
// Negli zip "clean" (es. build.sh del repo plugin) il file non esiste → noop.
if (file_exists(MITICKO_PLUGIN_DIR . 'includes/miticko-partner-config.php')) {
    require_once MITICKO_PLUGIN_DIR . 'includes/miticko-partner-config.php';
}

require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko.php';
require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko-logger.php';
require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko-client.php';
require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko-settings.php';
require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko-product-type.php';
require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko-sync.php';
require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko-frontend.php';
require_once MITICKO_PLUGIN_DIR . 'includes/class-miticko-preconfig.php';

register_activation_hook(__FILE__, ['Miticko', 'on_activate']);
register_deactivation_hook(__FILE__, ['Miticko', 'on_deactivate']);

add_action('plugins_loaded', ['Miticko', 'boot']);

add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});
